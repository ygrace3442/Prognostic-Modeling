"""
🤖 AutoGluon 단독 모델 - v5 (수정됨)
====================================
✅ 데이터 누수 수정: get_oof_pred_proba() 사용
"""

import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from autogluon.tabular import TabularPredictor
import os

# ============================================
# 🔧 설정
# ============================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

TRAIN_PATH = os.path.join(SCRIPT_DIR, 'open/train.csv')
TEST_PATH = os.path.join(SCRIPT_DIR, 'open/test.csv')
MODEL_PATH = './experiments/outputs/autogluon'

# ============================================
# 🧬 피쳐 엔지니어링 (v5와 동일)
# ============================================
def create_features(df):
    data = df.copy()
    epsilon = 1e-6
    
    # 1. '회' 제거
    cat_to_num_cols = [
        '총 시술 횟수', '클리닉 내 총 시술 횟수', 'IVF 시술 횟수', 'DI 시술 횟수',
        '총 임신 횟수', 'IVF 임신 횟수', 'DI 임신 횟수', 
        '총 출산 횟수', 'IVF 출산 횟수', 'DI 출산 횟수'
    ]
    for col in cat_to_num_cols:
        if col in data.columns:
            data[col] = data[col].astype(str).str.replace('회 이상', '').str.replace('회', '')
            data[col] = pd.to_numeric(data[col], errors='coerce')
    
    # 2. 나이 수치화
    age_map = {'만18-34세': 26, '만35-37세': 36, '만38-39세': 38.5, 
               '만40-42세': 41, '만43-44세': 43.5, '만45-50세': 47.5}
    if '시술 당시 나이' in data.columns:
        data['나이_수치'] = data['시술 당시 나이'].map(age_map).fillna(36)
    
    # 3. Binning
    if '나이_수치' in data.columns:
        data['연령_구간'] = pd.cut(data['나이_수치'], bins=[0,35,38,40,43,100], labels=[0,1,2,3,4]).astype(float).fillna(-1).astype(int)
    if '수집된 신선 난자 수' in data.columns:
        data['난자개수_구간'] = pd.cut(data['수집된 신선 난자 수'], bins=[-1,5,10,15,100], labels=[0,1,2,3]).astype(float).fillna(-1).astype(int)
    if '총 생성 배아 수' in data.columns:
        data['배아개수_구간'] = pd.cut(data['총 생성 배아 수'], bins=[-1,3,6,10,100], labels=[0,1,2,3]).astype(float).fillna(-1).astype(int)
    if '이식된 배아 수' in data.columns:
        data['이식배아_구간'] = pd.cut(data['이식된 배아 수'], bins=[-1,1,2,3,100], labels=[0,1,2,3]).astype(float).fillna(-1).astype(int)
    
    # 4. 효율성 지표
    if '이식된 배아 수' in data.columns and '수집된 신선 난자 수' in data.columns:
        data['난자_최종_활용률'] = data['이식된 배아 수'] / (data['수집된 신선 난자 수'] + epsilon)
    if '총 생성 배아 수' in data.columns and '혼합된 난자 수' in data.columns:
        data['배아_생성_효율'] = data['총 생성 배아 수'] / (data['혼합된 난자 수'] + epsilon)
    if '저장된 배아 수' in data.columns and '총 생성 배아 수' in data.columns:
        data['배아_저장_비율'] = data['저장된 배아 수'] / (data['총 생성 배아 수'] + epsilon)
    
    # 5. 교호작용
    if '나이_수치' in data.columns and '수집된 신선 난자 수' in data.columns:
        data['난소예비능_위험도'] = data['나이_수치'] / (data['수집된 신선 난자 수'] + epsilon)
    if '나이_수치' in data.columns and '총 생성 배아 수' in data.columns:
        data['나이_배아수_상호작용'] = data['나이_수치'] * data['총 생성 배아 수']
    if '나이_수치' in data.columns and '배아_생성_효율' in data.columns:
        data['나이_효율_상호작용'] = data['나이_수치'] * data['배아_생성_효율']
    if '나이_수치' in data.columns and '이식된 배아 수' in data.columns:
        data['나이대비_이식수'] = data['이식된 배아 수'] / (data['나이_수치'] + epsilon)
    if '미세주입된 난자 수' in data.columns and '혼합된 난자 수' in data.columns:
        data['ICSI_의존도'] = data['미세주입된 난자 수'] / (data['혼합된 난자 수'] + epsilon)
    
    # 6. 결측치 정보화
    if '난자 해동 경과일' in data.columns:
        data['신선배아_사용'] = data['난자 해동 경과일'].isnull().astype(int)
        data['난자 해동 경과일'] = data['난자 해동 경과일'].fillna(-1)
    if '배아 해동 경과일' in data.columns:
        data['신선배아_이식'] = data['배아 해동 경과일'].isnull().astype(int)
        data['배아 해동 경과일'] = data['배아 해동 경과일'].fillna(-1)
    if 'PGD 시술 여부' in data.columns:
        data['PGD_미실시'] = data['PGD 시술 여부'].isnull().astype(int)
    if 'PGS 시술 여부' in data.columns:
        data['PGS_미실시'] = data['PGS 시술 여부'].isnull().astype(int)
    if '임신 시도 또는 마지막 임신 경과 연수' in data.columns:
        data['첫시술_여부'] = data['임신 시도 또는 마지막 임신 경과 연수'].isnull().astype(int)
    
    # 7. 시술 이력
    if '총 임신 횟수' in data.columns:
        data['임신경험_여부'] = (data['총 임신 횟수'].fillna(0) > 0).astype(int)
    if '총 출산 횟수' in data.columns:
        data['출산경험_여부'] = (data['총 출산 횟수'].fillna(0) > 0).astype(int)
    if '총 시술 횟수' in data.columns:
        시술횟수 = data['총 시술 횟수'].fillna(1)
        data['재시술_여부'] = (시술횟수 >= 2).astype(int)
        data['다회시술_여부'] = (시술횟수 >= 4).astype(int)
    
    # 8. 난소 예비능 (AMH Proxy)
    if '수집된 신선 난자 수' in data.columns and '나이_수치' in data.columns:
        data['난자_채취_효율'] = data['수집된 신선 난자 수'] / (data['나이_수치'] + epsilon)
    if '수집된 신선 난자 수' in data.columns:
        conditions = [
            data['수집된 신선 난자 수'] <= 5,
            (data['수집된 신선 난자 수'] > 5) & (data['수집된 신선 난자 수'] <= 15),
            data['수집된 신선 난자 수'] > 15
        ]
        data['난소반응_등급'] = np.select(conditions, [0, 1, 2], default=-1)
    if '나이_수치' in data.columns and '수집된 신선 난자 수' in data.columns:
        data['고령_저반응'] = ((data['나이_수치'] >= 40) & (data['수집된 신선 난자 수'] <= 5)).astype(int)
    
    # 9. 누락 피쳐 보완 (모델 학습 시 사용된 피쳐)
    if '이식된 배아 수' in data.columns and '총 생성 배아 수' in data.columns:
        data['배아_이식_효율'] = data['이식된 배아 수'] / (data['총 생성 배아 수'] + epsilon)
    if '총 시술 횟수' in data.columns:
        data['시술횟수_수치'] = data['총 시술 횟수'].fillna(1)
    if '나이_수치' in data.columns and '총 시술 횟수' in data.columns:
        data['연령대비_시술밀도'] = data['총 시술 횟수'].fillna(1) / (data['나이_수치'] + epsilon)
    if '나이_수치' in data.columns and '이식된 배아 수' in data.columns:
        data['나이대비_배아이식수'] = data['이식된 배아 수'] / (data['나이_수치'] + epsilon)
    if '나이_수치' in data.columns and '배아_이식_효율' in data.columns:
        data['나이_배아품질_상호작용'] = data['나이_수치'] * data['배아_이식_효율']
    if '총 임신 횟수' in data.columns:
        data['임신경험_수치'] = data['총 임신 횟수'].fillna(0)
    if '총 출산 횟수' in data.columns:
        data['출산경험_수치'] = data['총 출산 횟수'].fillna(0)

    # 10. 불임 원인
    inf_cols = [c for c in data.columns if '불임 원인' in c]
    if inf_cols:
        data['불임원인_총개수'] = data[inf_cols].sum(axis=1)
        male_cols = [c for c in inf_cols if '남성' in c or '정자' in c]
        female_cols = [c for c in inf_cols if any(k in c for k in ['여성', '난관', '배란', '자궁'])]
        if male_cols:
            data['남성불임_여부'] = (data[male_cols].sum(axis=1) > 0).astype(int)
        if female_cols:
            data['여성불임_여부'] = (data[female_cols].sum(axis=1) > 0).astype(int)
        if '남성불임_여부' in data.columns and '여성불임_여부' in data.columns:
            data['복합불임_여부'] = ((data['남성불임_여부'] == 1) & (data['여성불임_여부'] == 1)).astype(int)
    
    return data

# ============================================
# 📊 메인 실행
# ============================================
if __name__ == "__main__":
    print("\n" + "="*60)
    print("🤖 AutoGluon 단독 모델 (v5) - 데이터 누수 수정됨")
    print("="*60)
    
    # 데이터 로드
    print("\n📊 Loading data...")
    train = pd.read_csv(TRAIN_PATH)
    test = pd.read_csv(TEST_PATH)
    print(f"   Train: {train.shape}, Test: {test.shape}")
    
    # 피쳐 엔지니어링
    print("\n🧬 Feature Engineering...")
    train_fe = create_features(train)
    test_fe = create_features(test)
    print(f"   Features: {train.shape[1]} → {train_fe.shape[1]} columns")
    
    # 저장된 AutoGluon 로드
    print("\n📂 Loading AutoGluon model...")
    if os.path.exists(MODEL_PATH):
        predictor = TabularPredictor.load(MODEL_PATH)
        
        # ✅ 수정됨: 올바른 OOF 예측 사용
        print("   Getting OOF predictions (no data leakage)...")
        try:
            # AutoGluon의 실제 OOF 예측 사용
            oof_pred_df = predictor.predict_proba_oof()
            
            if isinstance(oof_pred_df, pd.DataFrame):
                # 양성 클래스(1) 확률 추출
                if 1 in oof_pred_df.columns:
                    oof_pred = oof_pred_df[1].values
                else:
                    oof_pred = oof_pred_df.iloc[:, 1].values
            else:
                oof_pred = oof_pred_df
            
            print(f"   ✅ OOF predictions loaded: {len(oof_pred)} samples")
            
        except Exception as e:
            print(f"   ⚠️ OOF 예측을 가져올 수 없습니다: {e}")
            print("   💡 모델 학습 시 bagging이 활성화되어 있어야 OOF를 사용할 수 있습니다.")
            print("   ❌ predict_proba()는 데이터 누수가 발생하므로 사용하지 않습니다.")
            exit(1)
        
        # AUC 계산
        y_true = train['임신 성공 여부']
        auc = roc_auc_score(y_true, oof_pred)
        print(f"\n{'='*60}")
        print(f"🏆 AutoGluon CV AUC (정확한 OOF): {auc:.5f}")
        print(f"{'='*60}")
        
        # Test 예측 생성
        print("\n📤 Creating submission...")
        test_pred = predictor.predict_proba(test_fe)
        if isinstance(test_pred, pd.DataFrame):
            if 1 in test_pred.columns:
                test_pred = test_pred[1].values
            else:
                test_pred = test_pred.iloc[:, 1].values
        
        submission = pd.DataFrame({'ID': test['ID'], 'probability': test_pred})
        os.makedirs(os.path.join(SCRIPT_DIR, 'submissions'), exist_ok=True)
        submission.to_csv(os.path.join(SCRIPT_DIR, 'submissions', 'submission_autogluon_only.csv'), index=False)
        print(f"   ✅ submission_autogluon_only.csv 생성 완료!")
        print(f"   범위: {test_pred.min():.4f} ~ {test_pred.max():.4f}")
    else:
        print(f"   ❌ 모델 폴더가 없습니다: {MODEL_PATH}")
        print("   ultimate_model_v5.py를 먼저 실행해주세요.")
